# Bars Bar Chart

## Instructions

Using the [starter file](Unsolved/py_bars_unsolved.ipynb), create a bar chart that matches the image provided.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.
